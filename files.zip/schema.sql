-- ============================================================
-- FreelanceFlow — Schéma Supabase (PostgreSQL)
-- Exécuter dans : Supabase > SQL Editor > New Query
-- ============================================================

-- Extension UUID
create extension if not exists "uuid-ossp";

-- ============================================================
-- TABLE : profiles (profil utilisateur étendu)
-- ============================================================
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  name         text,
  email        text,
  phone        text,
  siret        text,
  tva_intra    text,
  address      text,
  iban         text,
  prefix_devis    text default 'DEV',
  prefix_facture  text default 'FAC',
  tva_rate     numeric(5,2) default 20,
  payment_delay int default 30,
  created_at   timestamptz default now(),
  updated_at   timestamptz default now()
);

-- ============================================================
-- TABLE : documents
-- ============================================================
create table if not exists public.documents (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  type          text not null check (type in ('devis', 'facture')),
  num           text not null,
  status        text not null default 'brouillon'
                  check (status in ('brouillon','envoyé','accepté','refusé','payé','en-retard')),
  date_creation date not null default current_date,
  date_echeance date,
  object        text,
  tva_rate      numeric(5,2) default 20,
  notes         text,
  client_name   text,
  client_email  text,
  client_phone  text,
  client_address text,
  client_siret  text,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ============================================================
-- TABLE : document_lines
-- ============================================================
create table if not exists public.document_lines (
  id          uuid primary key default uuid_generate_v4(),
  document_id uuid not null references public.documents(id) on delete cascade,
  user_id     uuid not null references auth.users(id) on delete cascade,
  position    int not null default 0,
  is_separator boolean default false,
  description text,
  qty         numeric(10,2) default 1,
  unit        text default 'heure',
  unit_price  numeric(10,2) default 0,
  created_at  timestamptz default now()
);

-- ============================================================
-- ROW LEVEL SECURITY (RLS) — Isolation stricte par user
-- ============================================================
alter table public.profiles       enable row level security;
alter table public.documents      enable row level security;
alter table public.document_lines enable row level security;

-- Profiles : un user ne voit que son propre profil
create policy "profiles_select" on public.profiles for select using (auth.uid() = id);
create policy "profiles_insert" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update" on public.profiles for update using (auth.uid() = id);

-- Documents : un user ne voit que ses documents
create policy "docs_select" on public.documents for select using (auth.uid() = user_id);
create policy "docs_insert" on public.documents for insert with check (auth.uid() = user_id);
create policy "docs_update" on public.documents for update using (auth.uid() = user_id);
create policy "docs_delete" on public.documents for delete using (auth.uid() = user_id);

-- Lines : idem
create policy "lines_select" on public.document_lines for select using (auth.uid() = user_id);
create policy "lines_insert" on public.document_lines for insert with check (auth.uid() = user_id);
create policy "lines_update" on public.document_lines for update using (auth.uid() = user_id);
create policy "lines_delete" on public.document_lines for delete using (auth.uid() = user_id);

-- ============================================================
-- FONCTION : auto-create profile on signup
-- ============================================================
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

-- Trigger sur auth.users
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- INDEX pour performances
-- ============================================================
create index if not exists idx_documents_user_id on public.documents(user_id);
create index if not exists idx_documents_type    on public.documents(type);
create index if not exists idx_lines_document_id on public.document_lines(document_id);

-- ============================================================
-- FIN
-- ============================================================
