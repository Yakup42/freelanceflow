# 🚀 FreelanceFlow — Guide de déploiement complet
> Mise en ligne **gratuite** en ~15 minutes. Zéro serveur, zéro CB.

---

## 🏗 Architecture

```
Navigateur (index.html)
        │
        ▼ HTTPS / Supabase JS SDK
┌───────────────────┐
│   Supabase        │  ← Base PostgreSQL + Auth + RLS
│   (Backend as a   │
│   Service, gratuit│
│   jusqu'à 500 MB) │
└───────────────────┘
        │
        ▼ Hébergement statique
┌───────────────────┐
│   Vercel / GitHub │  ← 1 fichier HTML, déploiement auto
│   Pages (gratuit) │
└───────────────────┘
```

---

## ÉTAPE 1 — Créer le projet Supabase

1. Aller sur **https://supabase.com** → "Start your project" → Créer un compte
2. Cliquer **"New project"**
   - Nom : `freelanceflow`
   - Mot de passe DB : (notez-le)
   - Région : **West EU (Ireland)** (le plus proche de Lyon)
3. Attendre ~2 min que le projet soit prêt

---

## ÉTAPE 2 — Créer la base de données

1. Dans votre projet Supabase → menu gauche **"SQL Editor"**
2. Cliquer **"New query"**
3. Copier-coller **tout le contenu** du fichier `schema.sql`
4. Cliquer **"Run"** (▶)
5. Vous devez voir : `Success. No rows returned`

---

## ÉTAPE 3 — Récupérer vos clés API

1. Menu gauche → **"Project Settings"** → **"API"**
2. Copier :
   - **Project URL** → ex: `https://abcxyzabc.supabase.co`
   - **anon / public** key → longue chaîne commençant par `eyJ...`

---

## ÉTAPE 4 — Injecter les clés dans index.html

Ouvrir `index.html`, trouver ces lignes (~ligne 540) :

```javascript
const SUPABASE_URL  = 'VOTRE_SUPABASE_URL';
const SUPABASE_KEY  = 'VOTRE_SUPABASE_ANON_KEY';
```

Remplacer par vos vraies valeurs :

```javascript
const SUPABASE_URL  = 'https://abcxyzabc.supabase.co';
const SUPABASE_KEY  = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';
```

> ✅ La clé `anon` est **publique par design** — elle est protégée par RLS côté Supabase.

---

## ÉTAPE 5 — Déploiement sur GitHub Pages (option A, la plus simple)

### 5.1 Créer un repo GitHub
1. Aller sur **https://github.com** → **"New repository"**
2. Nom : `freelanceflow` — Public — Créer

### 5.2 Uploader le fichier
```bash
# Si vous avez Git installé :
git init
git add index.html
git commit -m "init FreelanceFlow"
git branch -M main
git remote add origin https://github.com/VOTRE_USER/freelanceflow.git
git push -u origin main
```

Ou simplement : sur la page du repo → **"uploading an existing file"** → glisser `index.html`

### 5.3 Activer GitHub Pages
1. Repo → **Settings** → **Pages**
2. Source : `Deploy from a branch` → Branch: `main` → `/root`
3. Cliquer **Save**
4. URL disponible en ~1 min : `https://VOTRE_USER.github.io/freelanceflow/`

---

## ÉTAPE 5 (bis) — Déploiement sur Vercel (option B, custom domain facile)

1. Aller sur **https://vercel.com** → Créer un compte (gratuit)
2. **"Add New Project"** → Import depuis GitHub
3. Sélectionner le repo `freelanceflow`
4. Laisser les settings par défaut → **Deploy**
5. URL : `https://freelanceflow.vercel.app` (ou custom domain)

---

## ÉTAPE 6 — Configurer l'authentification Supabase

1. Supabase → **Authentication** → **URL Configuration**
2. Ajouter dans **"Site URL"** : votre URL de déploiement
   - Ex: `https://votre-user.github.io/freelanceflow`
   - Ou: `https://freelanceflow.vercel.app`
3. Ajouter la même URL dans **"Redirect URLs"**
4. Sauvegarder

---

## ÉTAPE 7 — Test final

1. Ouvrir votre URL publique
2. Créer un compte avec un vrai email
3. Confirmer l'email (vérifier les spams)
4. Se connecter → créer un devis → vérifier qu'il est sauvegardé

---

## 🔒 Sécurité — ce qui est déjà en place

| Mécanisme | Statut |
|-----------|--------|
| Row Level Security (RLS) | ✅ Chaque user ne voit QUE ses données |
| Auth JWT Supabase | ✅ Tokens signés, expiration auto |
| Clé anon publique | ✅ Sans RLS elle ne sert à rien — RLS est activé |
| HTTPS | ✅ Vercel/GitHub Pages forcent HTTPS |
| Pas de serveur custom | ✅ Aucune surface d'attaque back-end |

---

## 💡 Aller plus loin (monétisation)

### Option 1 — Vendre comme outil SaaS
- Ajouter **Stripe** pour un plan Pro (limite gratuit : 5 docs)
- Héberger sur un domaine custom : `freelanceflow.io` (~10€/an)
- Prix conseillé : **9.90€/mois** ou **79€/an**

### Option 2 — Vendre sur Gumroad
- Exporter le fichier `index.html` version offline
- Prix : **19€** (paiement unique, licence personnelle)
- Cibler : freelances, auto-entrepreneurs, étudiants en formation

### Option 3 — Proposer à des agences
- Version white-label (logo + couleurs custom)
- Tarif : **150-400€** la configuration sur mesure

---

## 🛠 Commandes de debug utiles

```bash
# Vérifier que Supabase répond
curl https://VOTRE_URL.supabase.co/rest/v1/ \
  -H "apikey: VOTRE_ANON_KEY"

# Vérifier les tables créées
# Supabase → Table Editor → vous devez voir : profiles, documents, document_lines
```

---

## 📁 Structure des fichiers

```
freelanceflow/
├── index.html     ← Application complète (1 seul fichier)
├── schema.sql     ← Script SQL à exécuter dans Supabase
└── DEPLOY.md      ← Ce guide
```

---

*FreelanceFlow — construit avec Supabase + HTML/CSS/JS vanilla*
*Zéro dépendance, zéro framework, zéro serveur à maintenir.*
